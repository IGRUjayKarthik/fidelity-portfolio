package com.workshop.tradr.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
/**
 * 
 * @author aravind
 *
 */
@Controller
public class PortFolioController
{

	private static final Logger logger = LoggerFactory.getLogger(PortFolioController.class);
	/**
	 * 
	 * @param locale
	 * @param model
	 * @return
	 * @throws SQLException 
	 */
	@RequestMapping(value = "/getmystocks", method = RequestMethod.GET)
	
	public String getMyStocks(final Locale locale, final Model model) throws SQLException
	{Connection con1=null;
	try {
	    
	    Class.forName("com.mysql.jdbc.Driver");
	    con1 =DriverManager.getConnection("jdbc:mysql://localhost:3306/tradr","root","");
	     Statement st=con1.createStatement();
	   ResultSet rs2=st.executeQuery("select c.CUSTOMER_ID,sp.STOCK_NAME,ch.QUANTITY,sp.STOCK_PRICE,ch.QUANTITY*sp.STOCK_PRICE from customer c,stock_price sp ,customer_holdings ch where ch.CUSTOMER_ID=c.CUSTOMER_ID and ch.STOCK_ID=sp.STOCK_ID ");		
	   double pa=0;
	   ArrayList<Stocks> stocks=new ArrayList<Stocks>();
	   while(rs2.next())
		 {
		   Stocks stock = new Stocks();
		   stock.setCi(rs2.getString(1));
		   stock.setCp(rs2.getDouble(4));
		   stock.setQ(rs2.getInt(3));
		   stock.setSn(rs2.getString(2));
		   double x = rs2.getDouble(5);
		   if
		   stock.setTot(x);
		
		 pa+=rs2.getDouble(5);
		 stocks.add(stock);
		 }
	   model.addAttribute("portfolio",pa);
	   model.addAttribute("stocks", stocks);
		
		} catch (Exception e) {
		    
		}
		finally { con1.close();}
		PortFolioController.logger.info("Logged");

		return "mystocks";
	}
	
	
	public String getHouseholdReports(final Locale locale, final Model model)
	{
		PortFolioController.logger.info("Logged");

		return "hshreports";
	}
	@RequestMapping(value = "/getProfile", method = RequestMethod.GET)
	
	
	public String getProfile(final Locale locale, final Model model) throws SQLException
	{
		Connection con=null;
		try {
		    
		    Class.forName("com.mysql.jdbc.Driver");
		    con =DriverManager.getConnection("jdbc:mysql://localhost:3306/tradr","root","");
		     Statement st=con.createStatement();
		   ResultSet rs=st.executeQuery("Select * from customer where Customer_id=101");
		while(rs.next())
		{
		  
         model.addAttribute("cid", rs.getString(1));
         model.addAttribute("name", rs.getString(2));
         model.addAttribute("Custlogin", rs.getString(3));
         model.addAttribute("dob", rs.getString(7));
         model.addAttribute("gender", rs.getString(8));
         model.addAttribute("it", rs.getString(9));
         model.addAttribute("hid", rs.getString(10));
       

		}
		
		
		} catch (Exception e) {
		    
		}
		finally { con.close();}

		PortFolioController.logger.info("Logged");

		return "Profile";
	}

	/**
	 * 
	 * @param locale
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/getIndReports", method = RequestMethod.GET)
	public String getIndustryReports(final Locale locale, final Model model)
	{
		PortFolioController.logger.info("Logged");

		return "indreports";
	}
	
	/**
	 * 
	 * @param locale
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/getStatement", method = RequestMethod.GET)
	public String getStatement(final Locale locale, final Model model)
	{
		PortFolioController.logger.info("Logged");

		return "statement";
	}

	/**
	 * 
	 * @param locale
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/watchlist", method = RequestMethod.GET)
	public String getWatchlist(final Locale locale, final Model model)
	{
		PortFolioController.logger.info("Logged");

		return "watchlist";
	}
}

